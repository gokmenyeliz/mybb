<?php
/**
 * MyBB 1.8
 * Copyright 2014 MyBB Group, All Rights Reserved
 * Website: http://www.mybb.com
 * License: http://www.mybb.com/about/license
 */

class pluginSystem
{
	/**
	 * The hooks to which plugins can be attached.
	 *
	 * @var array
	 */
	public $hooks;

	/**
	 * The current hook which we're in (if any)
	 *
	 * @var string
	 */
	public $current_hook;

	/**
	 * Stores a list of current nested hooks
	 *
	 * @var array
	 */
	public array $current_hook_stack = [];

	/**
	 * Keys of new global variables created in plugin hooks
	 *
	 * @var array-key[]
	 */
	private array $custom_global_keys = [];

	/**
	 * Load all plugins.
	 */
	function load()
	{
		global $cache, $plugins;

		$pluginList = $cache->read("plugins");
		if(!empty($pluginList['active']) && is_array($pluginList['active']))
		{
			foreach($pluginList['active'] as $plugin)
			{
				if($plugin != "" && file_exists(MYBB_ROOT."inc/plugins/{$plugin}.php"))
				{
					require_once MYBB_ROOT."inc/plugins/{$plugin}.php";
				}
			}
		}
	}

	/**
	 * Add a hook onto which a plugin can be attached.
	 *
	 * @param string $hook The hook name.
	 * @param callable $function The function of this hook.
	 * @param int $priority The priority this hook has.
	 * @param string|null $file The optional file belonging to this hook.
	 *
	 * @return boolean Whether the hook was added.
	 */
	function add_hook(string $hook, callable $function, int $priority = 10, ?string $file = ""): bool
	{
		if(!is_callable($function))
		{
			// $function isn't a valid callable, can't add hook
			return false;
		}

		if(is_array($function))
		{
			// Array of class/static function name or object/instance function name
			$methodRepresentation = $this->getMethodRepresentation($function);

			// Check to see if we already have this hook running at this priority
			if(!empty($this->hooks[$hook][$priority][$methodRepresentation]) && is_array($this->hooks[$hook][$priority][$methodRepresentation]))
			{
				return true;
			}

			// Add the hook
			$this->hooks[$hook][$priority][$methodRepresentation] = array(
				'class_method' => $function,
				'file' => $file,
			);
		}
		else if(is_object($function) && $function instanceof \Closure)
		{
			// Closure
			$functionId = spl_object_hash($function);

			// Check to see if we already have this hook running at this priority
			if(!empty($this->hooks[$hook][$priority][$functionId]) && is_array($this->hooks[$hook][$priority][$functionId]))
			{
				return true;
			}

			// Add the hook
			$this->hooks[$hook][$priority][$functionId] = array(
				'function' => $function,
				'file' => $file,
			);
		}
		else
		{
			// Function name string
			// Check to see if we already have this hook running at this priority
			if(!empty($this->hooks[$hook][$priority][$function]) && is_array($this->hooks[$hook][$priority][$function]))
			{
				return true;
			}

			// Add the hook
			$this->hooks[$hook][$priority][$function] = array(
				'function' => $function,
				'file' => $file,
			);
		}

		return true;
	}

	/**
	 * get the method representation for the given callable array.
	 *
	 * @param array $arr A callable array.
	 *
	 * @return string The string representation of the callable array.
	 */
	private function getMethodRepresentation(array $arr): string
	{
		if(is_string($arr[0]))
		{
			// Static class method
			return sprintf('%s::%s', $arr[0], $arr[1]);
		}

		return sprintf('%s->%s', spl_object_hash($arr[0]), $arr[1]);
	}

	/**
	 * Run the hooks that have plugins.
	 *
	 * @param string $hook The name of the hook that is run.
	 * @param mixed $arguments The argument for the hook that is run. The passed value MUST be a variable
	 *
	 * @return mixed The arguments for the hook.
	 */
	function run_hooks(string $hook, &$arguments = "")
	{
		global $mybb;

		if(!isset($this->hooks[$hook]) || !is_array($this->hooks[$hook]))
		{
			return $arguments;
		}

		$this->current_hook = $hook;

		$this->current_hook_stack[] = $this->current_hook;

		$existing_global_keys = [];

		if($mybb->config['compat_plugin_globals'] ?? true)
		{
			$existing_global_keys = array_keys($GLOBALS);
		}

		ksort($this->hooks[$hook]);

		foreach($this->hooks[$hook] as $priority => $hooks)
		{
			if(is_array($hooks))
			{
				foreach($hooks as $key => $hook)
				{
					if(!empty($hook['file']))
					{
						require_once $hook['file'];
					}

					if(array_key_exists('class_method', $hook))
					{
						$returnArgs = call_user_func_array($hook['class_method'], array(&$arguments));
					}
					else
					{
						$func = $hook['function'];

						$returnArgs = $func($arguments);
					}

					if($returnArgs)
					{
						$arguments = $returnArgs;
					}
				}
			}
		}

		if($mybb->config['compat_plugin_globals'] ?? true)
		{
			$new_global_keys = array_diff(
				array_keys($GLOBALS),
				$existing_global_keys,
			);

			$this->custom_global_keys = array_unique(
				array_merge(
					$this->custom_global_keys,
					$new_global_keys,
				)
			);

			$custom_globals = array_intersect_key(
				$GLOBALS,
				array_flip($this->custom_global_keys),
			);

			$legacy_template_variables = array_filter(
				$custom_globals,
				$this->has_scalar_values(...),
			);

			\MyBB\View\set($legacy_template_variables);
		}

		array_pop($this->current_hook_stack);

		$this->current_hook = end($this->current_hook_stack);

		return $arguments;
	}

	/**
	 * Remove a specific hook.
	 *
	 * @param string $hook The name of the hook.
	 * @param callable $function The function of the hook.
	 * @param int $priority The priority of the hook.
	 *
	 * @return bool Whether the hook was removed successfully.
	 */
	function remove_hook(string $hook, callable $function, int $priority = 10): bool
	{
		if(!is_callable($function))
		{
			return false;
		}

		if(is_array($function))
		{
			$methodRepresentation = $this->getMethodRepresentation($function);

			if(!isset($this->hooks[$hook][$priority][$methodRepresentation]))
			{
				return true;
			}

			unset($this->hooks[$hook][$priority][$methodRepresentation]);
		}
		else if(is_object($function) && $function instanceof \Closure)
		{
			// Closure
			$functionId = spl_object_hash($function);

			// Check to see if we don't already have this hook running at this priority
			if(!isset($this->hooks[$hook][$priority][$functionId]))
			{
				return true;
			}

			unset($this->hooks[$hook][$priority][$functionId]);
		}
		else
		{
			// Check to see if we don't already have this hook running at this priority
			if(!isset($this->hooks[$hook][$priority][$function]))
			{
				return true;
			}

			unset($this->hooks[$hook][$priority][$function]);
		}

		return true;
	}

	/**
	 * Establishes if a particular plugin is compatible with this version of MyBB.
	 *
	 * @param string $plugin The name of the plugin.
	 *
	 * @return boolean TRUE if compatible, FALSE if incompatible.
	 */
	function is_compatible(string $plugin): bool
	{
		global $mybb;

		// Ignore potentially missing plugins.
		if(!file_exists(MYBB_ROOT."inc/plugins/{$plugin}.php"))
		{
			return true;
		}

		require_once MYBB_ROOT."inc/plugins/{$plugin}.php";

		$infoFunc = "{$plugin}_info";
		if(!function_exists($infoFunc))
		{
			return false;
		}

		$pluginInfo = $infoFunc();

		// No compatibility set or compatibility = * - assume compatible
		if(empty($pluginInfo['compatibility']) || $pluginInfo['compatibility'] == "*")
		{
			return true;
		}

		$compatibility = explode(",", $pluginInfo['compatibility']);
		foreach($compatibility as $version)
		{
			$version = trim($version);
			$version = str_replace("*", ".+", preg_quote($version));
			$version = str_replace("\.+", ".+", $version);
			if(preg_match("#{$version}#i", $mybb->version_code))
			{
				return true;
			}
		}

		// Nothing matches
		return false;
	}

	/**
	 * Returns whether the provided value is scalar, or an array of scalar values.
	 */
	private function has_scalar_values(mixed $value, int $allowed_nesting = 10): bool
	{
		if(is_scalar($value))
		{
			return true;
		}
		elseif(is_array($value))
		{
			if($allowed_nesting === 0)
			{
				return false;
			}

			foreach($value as $item)
			{
				if(!$this->has_scalar_values($item, $allowed_nesting - 1))
				{
					return false;
				}
			}

			return true;
		}
		else
		{
			return false;
		}
	}
}

